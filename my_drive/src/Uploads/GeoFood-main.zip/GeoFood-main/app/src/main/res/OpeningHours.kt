data class OpeningHours(
    val open_now: Boolean
)