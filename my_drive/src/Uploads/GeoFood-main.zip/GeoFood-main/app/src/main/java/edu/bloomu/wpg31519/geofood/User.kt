package edu.bloomu.wpg31519.geofood

class User (
     var firstName:String,
     var lastName :String,
     var email:String
){

}