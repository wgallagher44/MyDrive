data class Geometry(
    val location: Location,
    val viewport: Viewport
)